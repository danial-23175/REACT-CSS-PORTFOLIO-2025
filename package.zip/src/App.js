// src/App.js
import React from 'react';
import Layout from './components/Layout';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import './App.css';

function App() {
  return <Layout />;
}

export default App;
