// src/pages/Experience.js
import React from 'react';

const Experience = () => {
  return (
    <section id="experience" className="py-5 text-center bg-light">
      <div className="container">
        <h2>Experience</h2>
        <p>2023 - Present: SEO and Digital marketing specialist .</p>
        <p>2021 - 2023: Web developer in wordpress , shopify and digital marketing </p>
      </div>
    </section>
  );
};

export default Experience;
